import pywhatkit
import pyautogui
import time
nohp = input('ketik no hp wa tujuan,diawali dengan +62 :')
pesan = input('ketik pesan yang akan dikirimkan :')
jam = int(input('ketik jam saat kirim(0-24) :'))
menit = int(input('ketik menit saat kirim(0-59) :'))
pywhatkit.sendwhatmsg(nohp,pesan,jam,menit)
time.sleep(1)
pyautogui.click()
time.sleep(1)
pyautogui.press('enter')
